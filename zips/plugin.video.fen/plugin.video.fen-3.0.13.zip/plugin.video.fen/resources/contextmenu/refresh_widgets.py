# -*- coding: utf-8 -*-
from xbmc import executebuiltin

executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=kodi_refresh)')
