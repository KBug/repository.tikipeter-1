# -*- coding: utf-8 -*-
from modules.router import routing
routing()
