# -*- coding: utf-8 -*-
from xbmc import executebuiltin

executebuiltin('RunAddon(plugin.video.fen)')
executebuiltin('UpdateLibrary(video,special://skin/foo)')
